package es.alumnos;

import static org.junit.jupiter.api.Assertions.assertTrue;
import org.junit.jupiter.api.Test;

/**
 * Unit test for simple App.
 */
public class AppTest {
    
    /**
     * Prueba básica para verificar que JUnit funciona
     */
    @Test
    void testApp() {
        assertTrue(true);
    }
}
