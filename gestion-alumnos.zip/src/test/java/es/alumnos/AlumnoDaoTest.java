package es.alumnos;

import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

class AlumnoDaoTest {

    @Test
    void insertar_llama_dao() {
        final AlumnoDao dao = Mockito.mock(AlumnoDao.class);
        final Alumno a = new Alumno("Alvaro", "Balas Jimenez", 19);

        dao.insert(a);
        Mockito.verify(dao, Mockito.times(1)).insert(a);
    }

    @Test
    void listar_devuelve_lista() {
        final AlumnoDao dao = Mockito.mock(AlumnoDao.class);
        Mockito.when(dao.findAll()).thenReturn(List.of(new Alumno("Alvaro", "Balas Jimenez", 19)));

        final List<Alumno> lista = dao.findAll();
        Assertions.assertEquals(1, lista.size());
    }
}
